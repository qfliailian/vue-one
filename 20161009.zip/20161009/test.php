<?php
	echo json_encode(array('name'=>'tac'));
?>